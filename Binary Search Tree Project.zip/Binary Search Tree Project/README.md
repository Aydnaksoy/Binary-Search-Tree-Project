# Proje 3 – Binary Search Tree (BST) Aşamaları

**Verilen Dizi:**  
`[7, 5, 1, 8, 3, 6, 0, 9, 4, 2]`

Binary Search Tree (BST) Aşamaları**

**Binary Search Tree**'de her düğümün:
- Sol alt ağındaki tüm düğümler küçük,
- Sağ alt ağındaki tüm düğümler büyük olur.

**Aşamalar:**

1. **Başlangıç:**
   - İlk eleman `7` kök (root) olur.  
   `root = 7`

2. **İkinci Eleman (5):**
   - `5` kök olan `7`'den küçük olduğu için **solda** yer alır.  
   `root = 7`, `sol = 5`

3. **Üçüncü Eleman (1):**
   - `1` hem `7`'den hem de `5`'ten küçük olduğu için **solda** yer alır.  
   `root = 7`, `sol = 5`, `solun solunda = 1`

4. **Dördüncü Eleman (8):**
   - `8` kök olan `7`'den büyük olduğu için **sağda** yer alır.  
   `root = 7`, `sağ = 8`

5. **Beşinci Eleman (3):**
   - `3` önce `7`'den küçük, sonra `5`'ten küçük, ancak `1`'den büyük olduğu için **5**'in sağında, **1**'in solunda yer alır.  
   `root = 7`, `sol = 5`, `solun solunda = 1`, `solun sağında = 3`

6. **Altıncı Eleman (6):**
   - `6` önce `7`'den küçük, sonra `5`'ten büyük olduğu için **5**'in sağında, **7**'nin solunda yer alır.  
   `root = 7`, `sol = 5`, `solun sağında = 6`, `sağ = 8`

7. **Yedinci Eleman (0):**
   - `0` hem `7`'den, hem `5`'ten, hem de `1`'den küçük olduğu için **1**'in solunda yer alır.  
   `root = 7`, `sol = 5`, `solun solunda = 1`, `solun solunun solunda = 0`

8. **Sekizinci Eleman (9):**
   - `9` önce `7`'den büyük, sonra `8`'den büyük olduğu için **8**'in sağında yer alır.  
   `root = 7`, `sağ = 8`, `sağın sağında = 9`

9. **Dokuzuncu Eleman (4):**
   - `4` önce `7`'den küçük, sonra `5`'ten büyük, sonra `3`'ten büyük olduğu için **3**'ün sağında yer alır.  
   `root = 7`, `sol = 5`, `solun solunda = 1`, `solun sağında = 3`, `3'ün sağında = 4`

10. **Onuncu Eleman (2):**
    - `2` önce `7`'den küçük, sonra `5`'ten küçük, sonra `1`'den büyük, son olarak `3`'ten küçük olduğu için **3**'ün solunda yer alır.  
    `root = 7`, `sol = 5`, `solun solunda = 1`, `solun sağında = 3`, `3'ün solunda = 2`

---

 **Sonuç Olarak BST:**

```
         7
       /   \
      5     8
     / \     \
    1   6     9
   / \     \
  0   3     4
     / \
    2
```

---

### **Özet:**
- **root = 7**
- `5` sol, `8` sağ
- `1` solun solunda, `3` solun sağında
- `6` 5'in sağında, `4` 3'ün sağında, `2` 3'ün solunda
- `9` sağın sağında, `0` 1'in solunda

